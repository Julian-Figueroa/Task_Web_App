'use strict'

var express = require('express');
var TaskController = require('../controllers/task');

var api = express.Router();

api.get('/', TaskController.getTask);
api.get('/:id', TaskController.getTaskDetail);
api.post('/create/:title/:dueDate/:priority', TaskController.createTask);
api.get('/destroy/:id', TaskController.deleteTask);
api.post('/update/:id', TaskController.updateTask);

module.exports = api;