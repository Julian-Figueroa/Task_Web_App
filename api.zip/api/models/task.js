'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var TaskSchema = Schema({
   title: String,
   description: String,
   owner: {type: Schema.ObjectId, ref: 'User'},
   priority: Number,
   dueDate: Date,
   creator: {type: Schema.ObjectId, ref: 'User'},
   taskStatus: String,
   createdAt: Date,
   updatedAt: Date
});

module.exports = mongoose.model('Task', TaskSchema);