'use strict'

var mongoose = require('mongoose');
var app = require('./app');
var port = process.env.PORT || 8282;

mongoose.connect('mongodb://localhost:27017/tracking', (err, res) => {
    if (err) {
        throw err;
    } else {
        console.log('Se ha conectado a la Base de Datos');

        app.listen(port, function() {
            console.log("Servidor API escuchando en http://localhost:" + port);
        });
    }
});