'use strict'
var moment = require('moment');
var User = require('../models/user');
var Task = require('../models/task');

function getTask(req, res) {
    var find = Task.find({}).sort('title');

    find.populate({ path: 'task' }).exec((err, task) => {
        if (err) {
            res.status(500).send({ errors: 'Something Went Wrong with the Server' });
        } else {
            if (!task) {
                res.status(404).send({ errors: 'Theres No Task in the DataBase' });
            } else {
                res.status(200).send({ task });
            }
        }
    });
}

function getTaskDetail(req, res) {
    var taskId = req.params.id;

    Task.findById(taskId, (err, task) => {
        if (err) {
            res.status(500).send({ message: 'Something Went Wrong with the Server' });
        } else {
            if (!task) {
                res.status(404).send({ message: 'Theres no such a task' });
            } else {
                res.status(200).send({ task });
            }
        }
    });
}

function createTask(req, res) {
    var task = new Task();
    var header = req.params;

    task.title = header.title;
    task.dueDate = header.dueDate;
    task.priority = header.priority;

    var params = req.body;
    task.owner = params.owner;
    task.creator = params.creator;
    task.taskStatus = params.taskStatus;

    var date = new Date();
    task.createdAt = date.toISOString();
    task.updatedAt = date.toISOString();

    if (header.title == null) {
        return res.status(500).send({
            data: null,
            message: 'Validation Error: Title' + header.title + 'Rule required failed',
            rule: "required",
            arg: [true]
        });
    }

    if (header.dueDate == null) {
        return res.status(500).send({
            data: null,
            message: 'Validation Error: dueDate' + header.dueDate + 'Rule required failed',
            rule: "required",
            arg: [true]
        });
    }

    if (typeof header.title != 'string') {
        return res.status(500).send({
            data: null,
            message: 'Validation Error: dueDate' + header.title + 'is not type String',
            rule: "string"
        });
    }

    var onTime = moment(header.dueDate, 'YYYY-MM-DD');

    if (onTime == null || !onTime.isValid()) {
        return res.status(500).send({
            data: null,
            message: 'Validation Error: dueDate' + header.dueDate + 'is not type Date',
            rule: "string"
        });
    }

    task.save((err, task) => {
        if (err) {
            res.status(500).send({ errors: 'Something Went Wrong with the Server' });
        } else {
            if (!task) {
                res.status(404).send({ errors: 'No Task was saved in the DataBase' });
            } else {
                res.status(200).send({ task: task });
            }
        }
    });
}

function deleteTask(req, res) {
    var taskId = req.params.id;

    if (taskId == null) {
        return res.status(400).send({
            data: null,
            message: 'The ID of Task is null'
        });
    }

    Task.findByIdAndRemove(taskId, (err, task) => {
        if (err) {
            res.status(500).send({ errors: 'Something Went Wrong with the Server' });
        } else {
            if (!task) {
                res.status(404).send({ errors: 'Id is not valid' });
            } else {
                res.status(200).send({ task });
            }
        }
    });
}

function updateTask(req, res) {
    var params = req.body;
    var taskId = req.params.id;

    var date = new Date();
    var updatedAt = date.toISOString();

    params.updatedAt = updatedAt;
    var update = params;

    if (taskId == null) {
        return res.status(400).send({
            data: null,
            message: 'The ID of Task is null'
        });
    }

    Task.findByIdAndUpdate(taskId, params, (err, task) => {
        if (err) {
            res.status(500).send({ errors: 'Something Went Wrong with the Server' });
        } else {
            if (!task) {
                res.status(404).send({ errors: 'Id is not valid' });
            } else {
                res.status(200).send({ task });
            }
        }
    });
}

module.exports = {
    getTask,
    getTaskDetail,
    createTask,
    deleteTask,
    updateTask
};